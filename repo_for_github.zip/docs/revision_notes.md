# Revision notes

Findings from the reanalysis, to be used in the revised paper and the response letter.
Numbers refer to the current results in `results/`.

## Data (stage 2)

1. **ICE files have no header row.** The original code dropped the first row of every
   file (8 rows per vehicle). Fixed: files are read with `header=None`.
2. **EV data are provided at 50 Hz**, not 25 Hz as stated in the paper
   (recorded at 25 Hz by Racebox; check Lapardhaja et al. for the resampling).
3. **Preprocessing was not uniform.** Different sampling rates (10 / 50 Hz) and different
   finite-difference schemes; point-to-point differencing at 50 Hz gives acceleration noise
   of the same size as the signal. Now: identical Savitzky-Golay filter (1 s window),
   derivative from the filter, both datasets resampled to 10 Hz.
4. **EV spacing includes vehicle length** (about 10.3 m at standstill; GPS antenna distance).
   ICE spacing definition still to be checked in Gunter et al. (2020).
5. **Quality control.** Kinematic check ds/dt vs. (v_l - v_f). Clean runs in both datasets
   stay below 0.45 m/s; 9 IONIQ 5 runs above 1.0 m/s, all from one recording
   (0_desired, 55 mph, run 2), excluded. 333 of 342 runs pass.
6. **Time headway near standstill** reaches very large values (e.g. 21.6 s at 0.48 m/s),
   which may explain why the pooled EV mean headway (2.16 s) exceeds the ICE mean (1.94 s).

## Models and stability (stage 3)

7. **Table 8 lambda_2 was computed incorrectly.** With the correct formula all 18
   configurations have lambda_2 > 0 (string unstable), consistent with the text.
   The reviewer's "contradiction" disappears.
8. **Use the dimensionless margin M = 1 + core / f_s** (string stable if M >= 1); for OVRV
   M = k1 tau^2 / 2 + k2 tau. lambda_2 and core have units and cannot be compared across
   vehicles.
9. **IDM in the original calibration code differed from the simulation code**
   (clipping of s* in calibration only). Now one implementation, exactly as in the paper.
10. **String instability is visible in the raw data**: the follower drops below the
    leader's minimum speed after each deceleration.

## Calibration (stage 4)

11. **Run selection.** Main results use EV runs with reduced speed 25/35/45 mph (speed range
    covered by the ICE data); all runs as a supplementary analysis.
12. **Bounds identical for ICE and EV**; original bounds differed between the two groups
    and many parameters sat at a bound.
13. **IDM delta and v0 fixed (20, 40 m/s).** With all six parameters free, 8 of 18
    configurations end at a bound: 4 degenerate (tau and delta at their lower bounds,
    RMSE gain 5-11 %), the others drive delta or v0 up, i.e. switch the free-road term off.
    Where no degeneracy occurs, fixing changes RMSE by at most 3 %.
14. **IDM beta upper bound 10 was too tight** (10 of 12 ICE configurations at the bound);
    with an upper bound of 100 beta settles at 4-38 for ICE and 3-5 for EV.
15. **Bound hits in the main results**: IDM 1/18, OVRV 2/18, all in the two EVs with a
    single free-flow speed (Model 3, Polestar 2), where the constant and speed-proportional
    parts of the spacing are not separable.
16. **Compare equilibrium headway and stability margin, not tau or beta.** tau trades off
    against s0 / eta; IDM beta is not robust to the run selection.
17. **At equal speed (22 m/s), EV and ICE equilibrium headways are similar**:
    ICE min 1.38-1.48 s vs. IONIQ 5 Short 1.35 s, Polestar 2 1.37 s;
    ICE max 2.20-2.66 s vs. IONIQ 5 XLong 2.37 s. The pooled spacing difference in the
    paper (32.6 vs. 45.4 m) reflects speed distribution and gap-setting mix.
18. **EV stability margin is consistently higher**: IDM 0.45-0.81 vs. ICE 0.14-0.43;
    OVRV 0.45-0.86 vs. 0.12-0.35. Robust to model choice and run selection.
    OVRV relative-speed gain k2: EV 0.35-0.59 vs. ICE 0.09-0.24.
19. **Cross-validation** (ICE: by profile, 4 folds; EV: by reduced speed, 3 folds).
    Interpolation folds: test RMSE 10-30 % above training RMSE. Extrapolation to unseen
    speeds (ICE stepH at 27-34 m/s; Polestar 2 down to 10 m/s): 2-4x the training RMSE.
    **Implication for the ring-road simulation**: EV data reach only about 27 m/s;
    low-density ring-road speeds are outside the EV calibration range.
20. **Model 3 cannot be represented by IDM or OVRV** (RMSE 4.3-5.4 m; late, hard braking
    and overshoot above the leader speed during recovery). Parameters are unstable
    (OVRV equilibrium headway 2.17 -> 3.16 s, measured 1.09-1.64 s, when the two
    5_desired runs are dropped). Excluded from the main stability and simulation results;
    included in a sensitivity analysis. Evidence for the need of EV-aware models.
21. **Classical models fit IONIQ 5 about as well as ICE** after uniform preprocessing and
    matched run selection (IDM RMSE 1.26-2.07 m vs. 1.18-3.50 m), contrary to the paper's
    statement that they fit ICE clearly better.

## Data quality (stage 5, addendum)

22. **GPS spacing at standstill is noisy.** Median spacing when stopped 8.6 m (5th percentile
    6.3 m, minimum 3.9 m, i.e. a negative net gap). All spacings below 8 m occur in runs with
    a stop and at speeds below about 1 m/s. Not used in the main analysis (reduced speed
    >= 25 mph). GPS spacing error of 1-2 m is comparable to the best model RMSEs (1.0-1.5 m).
23. **IONIQ 5 is 91 % of the EV data by duration** (3.99 of 4.37 h).

## Statistics (stage 5)

24. **The paper's pooled comparison is reproduced** (ICE vs EV: spacing 45.4 vs 34.1 m,
    d = 0.80; speed 23.6 vs 17.5 m/s, d = 1.12). With 10^5 samples every difference is
    "significant" (acceleration: d = 0.007, p = 0), so sample-level p-values are meaningless.
    The 15-25 m/s overlap band does not remove confounding: ICE mean speed is still higher
    (21.8 vs 20.4 m/s) and the gap-setting mix differs.
25. **Steady-state headway at matched speed and gap setting** (|a| < 0.2, |dv| < 0.3,
    2 m/s bins): IONIQ 5 Short and Polestar 2 lie inside the range of the six ICE min
    settings (19-21 m/s: ICE 1.34-1.54 s, IONIQ 5 1.45 s, Polestar 2 1.36 s); IONIQ 5 XLong
    inside the ICE max range (2.32-2.41 vs 2.17-2.88 s). Model 3 follows at a longer headway
    (about 1.95 s). **The tested EVs do not follow more closely.** Independent confirmation
    of the model-based equilibrium headways (note 17).
26. **Headway decreases with speed** for all configurations (e.g. VehA min 1.72 -> 1.38 s
    from 16 to 24 m/s): a constant-spacing component exists, consistent with s0 / eta > 0.
27. **Event-level response to leader decelerations** (584 events; leader drop >= 1.5 m/s;
    configuration-level medians, each configuration counted once, exact Mann-Whitney):
    for leader drops of 3-5 m/s, speed amplification ICE 1.24 vs EV 1.07 (p = 0.0002),
    overshoot 1.05 vs 0.29 m/s (p = 0.0002), response delay 3.4 vs 1.5 s (p = 0.0001).
    Delays do not overlap in any drop bin (ICE 2.0-5.1 s, EV 0.9-1.9 s).
    Within ICE, the max setting reacts later than the min setting; EV delays hardly depend
    on the gap setting.
28. **Confounder: the leaders brake differently.** Leader peak deceleration for 3-5 m/s drops:
    EV experiments 1.52 m/s2, ICE experiments 1.02 m/s2 (no overlap), so empirical matching
    on the disturbance is impossible.
29. **Counterfactual "same leader" test** with the calibrated IDM (main, without Model 3):
    every configuration follows the same recorded leaders. With EV-experiment leaders:
    amplification ICE 1.13 vs EV 1.04, delay 2.75 vs 1.80 s (p = 0.0006); with
    ICE-experiment leaders: 1.12 vs 1.02 (p = 0.0003), 3.25 vs 1.95 s (p = 0.0006).
    **The difference is not explained by the different disturbances.** The model compresses
    the empirical differences slightly but keeps their direction.
30. **Revised main message:** the tested EV ACC platforms do not follow more closely than
    the tested ICE platforms; they react about 1.5-2 s faster to leader decelerations and
    amplify them less, consistent with their higher stability margin (note 18).
31. **Counterfactual test is robust to the model choice.** With OVRV instead of IDM:
    EV-experiment leaders: amplification ICE 1.19 vs EV 1.05 (p = 0.004), delay 4.20 vs
    1.90 s (p = 0.0003); ICE-experiment leaders: 1.15 vs 1.03 (p = 0.0003), 4.28 vs 2.05 s
    (p = 0.0003). The deceleration ratio is not robust (IDM p = 0.44, OVRV p < 0.005) and
    should not be used as main evidence. All statistics are reproduced by
    `scripts/04_statistics.py` (outputs in `results/statistics/`).

## EV-aware extension and baselines (stage B)

32. **Models.** EV-aware extension: first-order actuation lag T_a between commanded and
    actual acceleration, added to IDM and OVRV (T_a = 0 recovers the original model).
    Baselines with explicit reaction time: Newell (speed form, one parameter tau) and
    Gipps (relaxation form, leader braking estimate = B, V fixed).
33. **In-sample, IDM + lag separates EV and ICE**: all 5 EV configurations use a non-zero
    lag (T_a 0.73-1.71 s, median 1.27 s; RMSE -4 to -21 %), whereas 7 of 12 ICE
    configurations have T_a ~ 0 (median 0.04 s; RMSE gain ~0 %). The IONIQ 5 lag is stable
    across cross-validation folds (range 0.18-0.28 s). Interpretation: the EV deceleration
    (short wait, then strong and brief braking) has a temporal shape that the instantaneous
    IDM cannot reproduce.
34. **T_a is not a physical powertrain constant.** (a) Its direction contradicts physics
    (EV larger than ICE); (b) it depends on the model: with OVRV, EV median 0.71 s vs ICE
    0.89 s, no separation; (c) with OVRV it is unstable across folds (ranges often > 1 s).
    The lag trades off against the controller gains (e.g. IONIQ 5 Short: IDM beta
    4.49 -> 1.71; OVRV k1 0.081 -> 0.011, k2 0.545 -> 0.906).
35. **Out of sample the lag does not help.** Paired difference in cross-validated test RMSE
    (mean [95 % bootstrap CI]): IDM + lag - IDM: EV -0.09 [-0.28, 0.07] m (3/5 better),
    ICE +0.03 [0.01, 0.06] m (1/12 better, i.e. overfitting); OVRV + lag - OVRV, all:
    -0.06 [-0.13, 0.01] m. Plain IDM is therefore used for the simulations.
36. **Baselines.** Cross-validated test RMSE, 17 configurations: IDM 2.42 [2.04, 2.86],
    IDM + lag 2.42 [2.01, 2.87], OVRV + lag 2.65, OVRV 2.71, Gipps 3.73 [3.31, 4.22],
    Newell 4.24 [3.59, 4.91] m. IDM beats Gipps and Newell in 17/17 configurations
    (paired differences -1.31 and -1.82 m, CIs far from 0). IDM vs OVRV: -0.28
    [-0.57, 0.01] m, not conclusive.
37. **Structural findings on the baselines.** Newell (pure delay, amplification exactly 1)
    has tau ~ 0.9 s for both groups because tau is fixed by the spacing-speed relation,
    not by the reaction time; its error is about twice that of IDM. Gipps: B runs to the
    upper bound (50) in 14/18 configurations; for B -> infinity the safe-braking branch
    degenerates to a spacing constraint, i.e. the safe-distance assumption does not
    describe ACC.
38. **Implication for the powertrain explanation.** EV-ICE timing differences are already
    reproduced by the controller parameters of plain IDM (note 29), while a parameter
    representing actuation cannot be identified. From trajectory data alone, powertrain
    actuation and ACC controller design cannot be separated; this needs commanded vs.
    actual acceleration (CAN bus data). The torque-curve explanation of the submitted
    paper is not supported and should be removed or stated as an untested hypothesis.
    Absence of evidence is not evidence that EV powertrains are not faster.

## Positioning of the revised paper (decided)

39. **Main contribution: an analysis framework for comparing ACC platforms recorded under
    non-harmonized protocols**, plus the empirical findings it yields:
    harmonized preprocessing and QC; identifiability-aware calibration (fixed
    non-identifiable parameters, bound checks, free-calibration comparison); grouped
    cross-validation with baselines; matched steady-state comparison; event-level response
    metrics with configuration-level tests; and the counterfactual "same leader" test that
    removes differences in the leader disturbances between campaigns.
40. **Main empirical message:** the tested EV ACC platforms do not follow more closely than
    the tested ICE platforms; they react faster to leader decelerations and amplify them
    less, and this difference is not caused by the different experimental disturbances.
    It cannot be attributed to powertrain actuation lag (EV-aware test, notes 32-38).
41. **To do in the reporting stage:** add uncertainty (bootstrap CIs over configurations,
    ranges over CV folds) to the event metrics, counterfactual results, equilibrium
    headways, stability margins and calibration errors; ring-road results with CIs over
    seeds.

## String stability (stage C, part 1; scripts/05_stability.py, results/stability/)

42. **Report lambda2 and M together.** lambda2 (Wilson & Ward 2011) has units 1/s: the
    growth rate of long-wavelength disturbances. Its sign decides stability; its magnitude
    scales with how fast a vehicle responds (rescaling time by c multiplies lambda2 by c and
    leaves M unchanged) and with 1/f_v^3, so it cannot rank vehicles. Example (IDM, 20 m/s):
    VehD min lambda2 = 4.13, M = 0.257; IONIQ 5 Short lambda2 = 5.77, M = 0.446, i.e.
    opposite rankings. M = 1 + core/f_s is dimensionless, equivalent (M >= 1 <=> lambda2
    <= 0), and reads as damping (relative-speed and own-speed response) over spacing
    stiffness, analogous to a damping ratio.
43. **All configurations are string unstable** at 10-25 m/s, for both models and in every
    CV fold (largest M: IONIQ 5 XLong 0.94 in its best fold).
44. **Compare within gap setting.** Longer settings are more stable (ICE max 0.27-0.43 vs
    ICE min 0.13-0.29 at 20 m/s, IDM). Within gap setting, EV and ICE separate even across
    CV folds: shortest setting ICE 0.12-0.30 vs EV 0.36-0.54; longest ICE 0.23-0.45 vs
    IONIQ 5 XLong 0.75-0.84. The paper's statement that instability decreases with speed
    does not hold for every configuration (several ICE max settings decrease).
45. **Polestar 2 OVRV stability is unreliable** (M fold range 0.16-0.38, lambda2 = 585;
    single steady speed, tau at its bound); use IDM for Polestar 2.
46. **Frequency-domain validation.** Linearized transfer function
    G(s) = (f_ds s + f_s) / (T_a s^3 + s^2 + (f_ds - f_v) s + f_s); max|G| <= 1 <=> M >= 1
    (500/500 random cases). Model max|G| at 20 m/s ranks the measured speed amplification
    of the configurations: Spearman rho = 0.72, p = 0.0012 (n = 17); EV 1.01-1.10 vs
    measured 1.00-1.12, ICE 1.13-1.53 vs measured 1.12-1.43.
47. **Mixed platoons replace the mean-field index S** (which has units and ignores order).
    Head-to-tail gain = product of the vehicle transfer functions, hence independent of the
    vehicle order. Monte Carlo: 30 vehicles, fixed counts per type, configurations drawn
    with replacement, 1000 platoons per mix. Per-vehicle amplification at 20 m/s, median
    [95 % interval]: 0 % EV 1.267 [1.228, 1.318] -> 100 % EV 1.053 [1.042, 1.064],
    nearly linear in the EV share (geometric averaging, no synergy). Still unstable at
    100 % EV. Same pattern at 15 m/s (1.297 -> 1.064) and 25 m/s (1.246 -> 1.045).
48. **Human-driven baseline** (Treiber & Kesting IDM, s0 + 5 m; reaction lag 0 / 0.5 / 1 s;
    6 parameter variants). Human-only: 1.000-1.054 at 20 m/s depending on the assumptions.
    Adding ICE-ACC increases the amplification strongly (to 1.267) for every variant;
    adding EV-ACC changes it little (to 1.053). With a 1 s human lag, EV-ACC is comparable
    to human driving (and a 20 % EV share slightly lowers the amplification, 1.054 ->
    1.039, because the peak frequencies differ). The literature IDM has no reaction time,
    so it likely overstates human stability: state results "relative to the literature
    human-driver model". At 25 m/s the human model is stable only through its free-road
    term (v0 = 33.3 m/s, delta = 4), so 20 m/s is the reference speed.
49. **Including Model 3 makes the EVs look more stable** (100 % EV: 1.038 instead of 1.053),
    because its unreliable IDM parameters give M = 0.90. Excluding it is conservative.

## Ring-road simulation (stage C, part 2; scripts/06_ring.py, results/ring/)

50. **Problems of the submitted simulation, all fixed:** hybrid VehC parameters used as ICE
    and table labels shifted; v0 ~50 m/s (ICE) vs 40 m/s (EV) from asymmetric calibration
    bounds; start from standstill (the start-up itself is the disturbance); no standard
    perturbation; spacing clipped (collisions hidden); warm-up described but not applied;
    one seed; fleets redrawn independently for every EV share; no human-driven vehicles.
51. **New design.** 30 vehicles, 15-100 veh/km, dt = 0.1 s. Start at the common equilibrium
    speed with each vehicle at its own equilibrium spacing. Standard perturbation of
    vehicle 0. 30 seeds per condition with common random numbers (raising a share only
    converts more vehicles; the others are unchanged). Common hard speed cap 26.8 m/s
    (60 mph) acting as the ACC set speed; model parameters are not modified (changing v0
    would alter the human IDM car following because delta = 4). Three scenarios:
    ICE-ACC + EV-ACC (the paper's question), human + ICE-ACC, human + EV-ACC.
52. **Why two analyses.** All ACC fleets are string unstable, so a fixed-length run first
    shows wave growth and then a saturated stop-and-go state with speeds between 0 and the
    cap. Stop-and-go is outside the calibrated speed range (main runs >= 11 m/s; the ICE
    data contain no stops): e.g. 100 % ICE-ACC reached a head-to-head spacing of 2.55 m,
    equal to the extrapolated s0 of VehF max, i.e. physically a collision. Hence:
    A (main) growth of a small perturbation (1 m/s2 for 2 s) while every vehicle stays in
    11-26.8 m/s; B (supplementary) 1200 s runs (600 s warm-up) to the final stop-and-go
    state with a common minimum head-to-head spacing of 7 m (vehicle length + 2 m), which
    limits a vehicle's speed only when it would otherwise come closer.
53. **Analysis A covers 15-30 veh/km fully** (40 veh/km partially; >= 50 veh/km starts below
    the calibrated range). No collisions. At 30 veh/km, median growth rate (1/s) and median
    time to leave the calibrated range:
    ICE-ACC + EV-ACC, EV share 0 -> 100 %: 0.031 -> 0.016; 62 -> 178 s (about 3x longer).
    Human only: -0.005 (the perturbation decays; literature IDM, 0.5 s lag).
    Human + ICE-ACC at 20 / 40 / 100 %: 0.009 / 0.020 / 0.031.
    Human + EV-ACC at 20 / 40 / 100 %: 0.002 / 0.007 / 0.016 (40 %: 430 s to leave the range).
    Same ordering as the linear stability analysis (notes 47-48): the nonlinear simulation
    confirms the frequency-domain results.
54. **Reporting rule for censored times.** Seeds that never leave the range get
    time_to_exit > (duration - perturbation start) = 540 s; report the median with this
    censoring ("> 540 s" if the median is censored) and the share of seeds that never leave.
55. **Possible hint on the ICE spacing definition.** Several calibrated ICE s0 values are
    below a vehicle length (2.5-4.3 m). They are extrapolated intercepts (no ICE data below
    ~13 m/s), so this is not conclusive, but it raises the possibility that the ICE spacing
    is a net gap whereas the EV spacing includes the vehicle length. Check Gunter et al.
    (2020) with priority; it affects standstill spacing and headway comparisons.
56. **Refined steady-state claim** (Table 2 and Table 4). Comparable speed bins only (no ICE
    steady data above 25 m/s). Measured, shortest setting: IONIQ 5 Short inside the ICE min
    range in 2/3 bins, below it at 15-17 m/s (1.47 vs 1.58-1.72 s); Polestar 2 inside in
    3/3; Model 3 above in 2/3 (about 1.95 s). Longest setting: IONIQ 5 XLong inside in 3/3.
    Model-based at 20 m/s: ICE min 1.43-1.50 s, IONIQ 5 Short 1.39 s, Polestar 2 1.40 s.
    Statement for the paper: at matched speed and gap setting the tested EVs differ from the
    tested ICE vehicles by at most about 0.1 s (about 5 %), far less than the difference
    between gap settings (about 1.4 vs 2.4 s) and comparable to the spread among ICE vehicles.
    The equilibrium headway is stable across CV folds (typically +-0.02-0.05 s) even where
    tau and s0 trade off.
57. **Analysis B (final stop-and-go state, supplementary).** No collisions. At 15 veh/km all
    fleets run free at the speed cap (1447 veh/h). ICE-ACC + EV-ACC: a higher EV share gives
    higher final flow and less stopping at every density from 20 to 100 veh/km
    (30 veh/km: 727 vs 1239 veh/h; stopped 57 % vs 22 %). The final states differ, not
    only the growth rates (corrects the guess made after the first example run).
    Human only (literature IDM, 0.5 s lag) stays free up to 30 veh/km (peak about
    2440 veh/h); adding 20 % of either ACC type already lowers the final flow strongly,
    more so for ICE-ACC. The speed cap matters: at 20 veh/km EV-rich fleets equilibrate at
    the cap with spare spacing and no waves develop (jump from 1053 to 1930 veh/h between
    40 % and 60 % EV).
58. **Extrapolation artefacts in analysis B.** At 100 veh/km the fully ICE fleet does not move
    at all: several ICE s0 values (11-17 m, extrapolated from data above 13 m/s) exceed the
    10 m available per vehicle. High-density results of analysis B depend on the low-speed
    extrapolation and on the assumed 7 m minimum spacing; report them as illustrative only.
59. **Bug found and fixed in analysis B.** The minimum-spacing constraint only prevented
    vehicles from coming closer; the initial equilibrium ignored it, so vehicles with small
    s0 (VehE max 3.4 m, VehF max 2.6 m) started below 7 m at low equilibrium speeds and
    stayed there (min spacing 2.75 m in 35 runs at 100 veh/km). Fix: equilibrium spacings
    are floored at the minimum spacing; the speed limit is iterated until no speed changes.
    15 affected parts (80 and 100 veh/km, fleets with ICE-ACC) were recomputed. Analysis A
    does not use the minimum spacing and is unaffected. Regression tests in
    tests/test_simulation.py.

## Spacing definitions and reconciliation with prior work (reviewer comment 4)

60. **The two datasets use different spacing definitions** (found while reconciling with
    the original papers). ICE: space gap from GPS antennas whose positions on each vehicle
    were recorded to calculate the gap (Gunter et al. 2021); de Souza and Stern call it the
    bumper-to-bumper spacing, i.e. a net gap. EV: Racebox GPS on the windshields, spacing
    from the two positions by the Haversine formula (Zare et al. 2023); Lapardhaja et al.
    (2023) set it up front bumper to front bumper and subtract about 4.6 m when converting
    minimum headway to time gap (e.g. 1.23 s vs 1.06 s at 96 km/h). The submitted paper and
    our first reanalysis compared the two definitions directly.
61. **Fix.** All analyses use the net gap. EV spacing minus the leader length: IONIQ 5
    followed a 2021 Toyota Camry (4.88 m), Model 3 and Polestar 2 a 2022 Toyota Corolla
    (4.63 m) (Lapardhaja et al. 2023). The raw value is kept as s_raw. Check: median EV
    standstill net gap 3.44 m over 59 runs (raw 8.61 m). One run had a negative standstill
    net gap for the whole stop (IONIQ 5 XLong 35->0 mph, run 2: -0.87 m), i.e. a constant
    spacing bias that the kinematic check cannot see; new QC rule: median standstill net gap
    >= 0 m. 332 of 342 runs pass. Ring simulation: states are net gaps, ring length minus
    5 m per vehicle; human-driver s0 = 2 m (literature value); minimum gap 2 m.
62. **Consequence: the steady-state conclusion is reversed.** Rough check at 19-21 m/s,
    shortest setting: IONIQ 5 1.20 s, Polestar 2 1.12 s, ICE min 1.34-1.54 s, Model 3 1.73 s.
    The tested IONIQ 5 and Polestar 2 do follow more closely than all tested ICE vehicles
    (notes 17, 25 and 56 were artefacts of the mixed definitions). Unaffected by the offset:
    event metrics (speed based), OVRV k1, k2, tau and the margin M (the offset only shifts
    eta), the kinematic QC. Affected: headways, IDM parameters and everything built on them
    (IDM stability, counterfactual, ring simulation). Full rerun from step 03; old results
    kept in results_before_net_gap/. Caveat for the paper: 2022-23 EVs vs 2018 ICE vehicles,
    different test sites, leaders and years; do not attribute the difference to the
    powertrain.
63. **Reconciliation, ICE (Gunter et al. 2021, Table II).** Their OVRV includes a sensor
    delay and is calibrated on speed MSE; ours has no delay and is calibrated on spacing
    RMSE. k1 and k2 still agree closely, e.g. A min 0.053/0.293 vs ours 0.059/0.238,
    B min 0.049/0.139 vs 0.047/0.143, G min (our VehF min) 0.064/0.183 vs 0.059/0.183.
    t_h and eta trade off (their eta bound 15 m, ours 25 m) but equilibrium headways agree
    (E min at 22 m/s: 1.50 vs 1.51 s). They find all seven vehicles string unstable in
    both settings, as we do. Their text identifies Vehicle C as the hybrid, which confirms
    our exclusion and the renumbering D-G -> VehC-VehF.
64. **Reconciliation, EV (Zare et al. 2023, same IONIQ 5 data).** Their OVRV gives
    M = k1 tau^2/2 + k2 tau = 0.38 / 0.60 / 0.52 / 0.66 (Short / Medium / Long / XLong),
    ours 0.45 / 0.55 / 0.64 / 0.86: same range, all unstable. Their XLong eta = 15.00 sits
    at their upper bound. They also find smaller amplification for the EV than for an ICE
    parameter set from the literature.
65. **Reconciliation, EV (Lapardhaja et al. 2023).** IONIQ 5 Short minimum headway
    1.23-1.44 s (front to front), increasing from Short to XLong, as in our data. They
    observed no amplification for the IONIQ 5 and slight amplification for the Polestar 2
    (ours: 1.00-1.10 and 1.12). They hypothesised that EVs might improve stability and
    called for simulations; our analysis tests this: EVs have clearly higher margins but
    remain string unstable. They report that the Tesla Model 3 cannot hold a constant
    headway even in steady state and behaves like an ICE ACC, an independent reason for
    excluding Model 3 from the model-based results. Their ICE comparison uses a different
    ICE dataset (Chon Kan et al. 2021), not the Gunter et al. data. Data were recorded at
    25 Hz; the published files are at 50 Hz.

## Results after unifying the spacing definitions (net gap; full rerun of steps 03-07)

66. **Superseded notes.** Notes 17, 25 and 56 (EVs do not follow more closely) are wrong:
    they compared EV front-to-front spacing with ICE net gaps. Numbers in notes 35, 47, 48,
    53, 57 and 58 are replaced below. Old results are kept in results_before_net_gap/.
67. **Unchanged, as expected.** ICE calibration and stability: identical (max change 0).
    Event metrics (configuration medians): identical. OVRV margins of the EVs: change
    <= 0.006 (Model 3 excepted). Model vs measured amplification: Spearman rho = 0.72,
    p = 0.0012, unchanged.
68. **Steady-state headway (net gap), shortest setting.** IONIQ 5 Short 1.16 / 1.20 / 1.13 s
    and Polestar 2 Short 1.41 / 1.12 / 1.14 s at 15-17 / 19-21 / 23-25 m/s, below the ICE
    min range in all three bins (ICE 1.58-1.72 / 1.34-1.54 / 1.24-1.46 s). At 19-21 m/s
    IONIQ 5 Short is about 0.3 s (20 %) below the ICE median. Longest setting: IONIQ 5 XLong
    2.03 / 2.16 / 2.17 s, below or at the lower edge of ICE max (2.31-2.88 / 2.24-2.81 /
    2.17-2.55 s). Model 3 is looser (1.73-1.76 s above 19 m/s). Consistent with Lapardhaja
    et al. (2023). Statement: the tested IONIQ 5 and Polestar 2 follow more closely than
    all six tested ICE vehicles at matched speed and setting (different model years,
    sites and leaders; not attributable to the powertrain from these data).
69. **EV IDM parameters (main).** s0 drops by 4.5-5.5 m (e.g. IONIQ 5 Short 8.38 -> 3.48 m),
    tau almost unchanged (0.97 -> 0.97 s), alpha slightly lower, beta higher; spacing RMSE
    equal or slightly lower. IONIQ 5 XLong s0 = 0.53 m, close to the lower bound: s0 is an
    extrapolated intercept (no stops in the main runs); the equilibrium headway is robust.
    IDM margin M at 20 m/s: EV change -0.03 to +0.02; within gap setting the EVs remain
    above the ICE vehicles (shortest 0.42-0.54 vs 0.13-0.29; longest 0.81 vs 0.27-0.43).
70. **Model comparison and the lag test (replaces note 35).** Test RMSE: IDM 2.39, IDM + lag
    2.40, OVRV + lag 2.65, OVRV 2.70, Gipps 3.72, Newell 4.24 m. IDM - OVRV, all
    configurations: -0.31 [-0.59, -0.03] m, p = 0.045 (now reliable). IDM + lag - IDM:
    EV -0.07 [-0.15, -0.01] m (4/5 better, Wilcoxon p = 0.19), ICE +0.03 [0.01, 0.06] m
    (1/12 better, overfitting). OVRV + lag - OVRV, EV: -0.07 [-0.26, 0.10] m. T_a (IDM + lag):
    EV 0.66-1.12 s (median 0.85 s, fold ranges 0.15-0.42 s), ICE median 0.04 s (identical
    to before). Interpretation: the lag gives a small but consistent gain for the EVs only
    (about 3 %, far below the 1-2 m GPS spacing error); it captures the wait-then-brake
    shape of the EV response. It is not a powertrain response time: EVs need the longer
    lag, and OVRV shows no EV/ICE separation.
71. **Mixed platoons (replaces note 47-48 numbers), 20 m/s.** ICE-ACC + EV-ACC: 1.267 -> 1.059
    from 0 to 100 % EV. Human-driven IDM with s0 = 2 m: 1.000 (lag 0 or 0.5 s), 1.082 (1 s).
    Adding ICE-ACC raises the amplification to 1.267, adding EV-ACC to 1.059.
72. **Ring road (replaces note 53 and 57 numbers).** Ring length minus 5 m per vehicle.
    Analysis A at 30 veh/km, median growth rate (1/s): 100 % ICE-ACC 0.042, 100 % EV-ACC
    0.017 (ratio about 2.5, previously 1.9), human only -0.014. Analysis A covers 15-30 veh/km
    fully, 40-60 veh/km partly. Analysis B: no collisions, smallest net gap 2.0 m.
73. **Frozen fleets in analysis B (replaces note 58).** With net gaps and the vehicle bodies,
    at 80 veh/km only 7.5 m of net gap per vehicle remain, less than the extrapolated s0 of
    several ICE configurations (11-17 m): fleets with many ICE vehicles cannot move at all
    (jam regime in 100 % of seeds at 80 veh/km with 0 % EV). Figure S1 omits densities where
    more than half of the seeds start in this regime.

## Positioning of the revised paper, final (replaces note 40)

74. **Main empirical message.** The tested EV ACC platforms (IONIQ 5, Polestar 2) both
    follow more closely and respond better than the tested ICE ACC vehicles:
    (a) at matched speed and gap setting their steady-state time gap (net gap) is shorter
        than that of all six ICE vehicles, about 0.3 s (20 %) at 20 m/s (note 68);
    (b) they react faster to leader decelerations and amplify them less (notes 27-31);
    (c) the difference in (b) is not caused by the different leader disturbances of the two
        campaigns (same-leader counterfactual, IDM and OVRV);
    (d) their stability margins are higher within each gap setting, but every tested
        configuration remains string unstable (notes 43-44, 69);
    (e) the differences cannot be attributed to powertrain actuation from trajectory data:
        an explicit actuation lag gives a small gain for the EVs only, but in the wrong
        physical direction and not robust to the model structure (note 70).
    Closer following is usually expected to reduce stability; the tested EVs combine
    shorter gaps with less amplification. Scope: two EV models vs six 2018 ICE models
    recorded in different campaigns; Model 3 behaves differently (looser gaps, no model
    fits; also reported by Lapardhaja et al. 2023).
75. **Main contribution** (unchanged from note 39): an analysis framework for comparing ACC
    platforms recorded under non-harmonized protocols. Its parts and what each one fixes:
    harmonized preprocessing and QC, including a common spacing definition (net gap);
    identifiability-aware calibration; grouped cross-validation with baselines; matched
    steady-state comparison; event-level metrics with configuration-level tests; the
    same-leader counterfactual; frequency-domain stability validated against measured
    amplification; ring-road simulations restricted to the calibrated speed range.
76. **Revision without a response letter.** Every reviewer concern must be resolved in the
    paper itself: (1) contribution stated as the framework plus a tested EV-aware extension;
    (2) confounding addressed in the methods (matched comparison, counterfactual) and in a
    limitations paragraph; (3) baselines in the model comparison; (4) a paragraph comparing
    with Gunter et al. (2021), Zare et al. (2023) and Lapardhaja et al. (2023) (notes 63-65);
    (5) human-driven baseline in the stability and ring sections; (6) parameter bounds and
    identifiability in the calibration section; (7) lambda2 and M reported together with the
    corrected values; (8) uncertainty (bootstrap CIs, CV-fold ranges, 30 seeds) in every
    table and figure.

77. **Bug found and fixed in analysis A (ring road).** The in-range check of
    scripts/06_ring.py computed the equilibrium speed with the full ring length, whereas
    simulate_ring uses the ring length minus the vehicle bodies since the net-gap
    unification. Fleets whose actual equilibrium speed was at the lower edge of the
    calibrated range were therefore admitted and left the range almost immediately
    (median time to exit 1 s for 100 % ICE-ACC at 30 veh/km; the dashed line of Fig. 9a
    at about 60 s showed the same problem). Fix: the check uses the same geometry as the
    simulation. Analysis A was rerun; analysis B, the stability analysis and all other
    steps are unaffected.


## Final revision for Digital Transportation and Safety

78. **Two figures added to the paper (Fig. 2 and Fig. 6).** `figA_gap_definition` is a
    schematic of the reported spacing in the two datasets (ICE: net gap; EV: front to front,
    net gap = s_raw - L_l). `figBa_response_ice` and `figBb_response_ev` show the speed drop
    of leader and follower around leader decelerations of 3-5 m/s, normalized by the leader
    drop and aligned at the start of the deceleration (thin lines: configuration medians;
    thick lines: median over configurations). Code: `figures.fig_gap_definition`,
    `figures.fig_event_response`, `src/analysis/event_curves.py` (cache
    `results/data_summary/event_curves.csv`, rebuilt when `results/statistics/events.csv` is
    newer). Events used: 103 ICE and 54 EV, as in the event table; the median delays 3.40 s
    (ICE) and 1.50 s (EV) come from `event_config_medians.csv`. File names keep the code
    numbering; the manuscript numbers the floats by position (see README).

79. **Table of parameters and bounds is generated from `config/experiment.yaml`**
    (`src/reporting/table_bounds.py` -> `tableS1_bounds.tex`, manuscript Table 3). It was
    typed by hand before. Numbers are written in the shortest form (4 instead of 4.0).

80. **Layout fixes of three tables** (`src/reporting/latex_fixes.py`, applied at the end of
    step 07): steady-state time gap (ICE range and median in separate rows, so the table
    fits the text width without scaling), identifiability table (two-level header, bounds as
    superscripts: + upper, - lower), paired model comparisons (typographic minus signs).

81. **Model 3 responds like the other EVs.** Leader drops of 3-5 m/s: speed amplification
    1.08 and response delay 1.5 s (EV median 1.06 and 1.50 s; ICE median 1.24 and 3.40 s);
    drops of 7-12 m/s: 1.08 and 1.7 s. Only its steady-state gap differs (1.73-1.76 s above
    19 m/s, above the ICE range). Lapardhaja et al. (2023) call it ICE-like because it does
    not regain its initial headway after a speed fluctuation; the event metrics cover only
    the deceleration phase. The manuscript now says that all three EVs respond earlier and
    that the Model 3 differs in its steady-state gap.

82. **All numbers of the manuscript were checked against `results/`** (stability, ring road,
    statistics, calibration, quality control). Everything agrees except for these items,
    corrected in the text: (a) 0.4 m / 20 m/s = 0.02 s (was 0.015 s); (b) OVRV gains of VehA
    min and VehF min are 0.059/0.238 and 0.059/0.183 here versus 0.053/0.293 and 0.064/0.183
    in Gunter et al. (the order was reversed in the text); (c) M < 1 holds for every cross-
    validation fold of the 17 model-based configurations (largest fold value 0.98) but not
    for the Model 3 (fold maximum 1.16 for IDM and 1.33 for OVRV at 20 m/s); (d) the ranges
    at an ACC share of 40 % (1.062-1.104 with ICE ACC, 1.000-1.029 with EV ACC) belong to a
    human lag of 0.5 s (1 s: 1.076-1.124 and 1.000-1.045); (e) 1.059^30 = 5.5 (was 'about
    6'); (f) the spread of the equilibrium time gap over folds is 0.02-0.13 s for the 17
    configurations (0.18 s with the Model 3); (g) M of IONIQ 5 XLong at 20 m/s is 0.80 (was
    0.81).

83. **Comparison with published values rechecked.** Zare et al. (2023), Table I: M = k1
    tau^2/2 + k2 tau gives 0.38, 0.60, 0.52 and 0.66 for Short, Medium, Long and XLong (here
    0.44, 0.55, 0.64 and 0.87). Lapardhaja et al. (2023), Table 2: minimum headway of the
    IONIQ 5 at the Short setting 1.23-1.44 s (front to front); the ICE vehicle of their
    earlier experiments has 1.89 s on average; Polestar 2 shows slight amplification and
    Model 3 ICE-like behavior.

84. **Reference list (`references.bib`) left unchanged by decision.** Differences to the
    publisher records, for the record: `gunter2019model` is IEEE T-IV 5(1), 90-99, March
    2020 (bib: 2019); `shang2022novel` is IEEE T-ITS 23(9), 15696-15706 (volume, issue and
    pages missing); `talebpour2024third` is a U.S. DOT ITS JPO final report, May 2024 (no
    venue given); `tibshirani1993introduction` is the book by Efron and Tibshirani (Chapman
    & Hall, 1993); `punzo2014we` is volume 16, i.e. 2015; `gunter2020commercially` is IEEE
    T-ITS 22(11), November 2021; `yang2026microsimacc` has the DOI
    10.1080/23249935.2024.2349921 (first published online in 2024; volume 22(1) not
    verified).
